# Privacy Shield Browser — Android Studio source

A Kotlin Android browser starter using Mozilla GeckoView. This ZIP contains source code, **not a prebuilt or tested APK**.

## Included
- GeckoView browser with address/search bar, back, forward and reload.
- Strict tracking-protection level requested for the active GeckoSession.
- Dashboard-first interface for network, fingerprint, device and storage status.
- One-Click Protect performs only real operations currently implemented: deletes this app's cache directories where possible and rotates the app-scoped UUID. It does not claim to clear GeckoView cookies/site storage or change your network identity.
- Privacy settings menu, manual browserleaks.com test page, and Android VPN settings shortcut.
- Honest status labels for features that still need implementation/configuration.

## VPN status — important
There is **no in-app VPN tunnel or VPN server profile** in this starter. A VPN requires a real provider/server and valid configuration. The button opens Android's VPN settings; it does not make this app itself a VPN. To add a true in-app WireGuard tunnel, a valid WireGuard `.conf` profile and a maintained WireGuard tunnel backend must be integrated and tested. A config cannot be invented if there is no server/provider.

## Not implemented / not guaranteed
- Clearing GeckoView cookies, local storage, cache storage, or all browsing history.
- Custom User-Agent override, verified WebRTC blocking, custom DNS/DoH routing, or complete Canvas/WebGL/AudioContext anti-fingerprinting.
- Reading or resetting Android Advertising ID, IMEI, or identifiers of other apps.
- A working VPN tunnel, automatic public-IP/DNS/WebRTC measurements, or guaranteed anonymity.
- Full per-site permission UX and Firefox WebExtension management UI.

Strict tracking protection is not equivalent to anonymity. Verify VPN/IP/DNS/WebRTC behavior with independent tests after a real VPN is connected.

## Build in Android Studio
1. Install current Android Studio and Android SDK Platform 35.
2. Open this project folder and allow Gradle sync (internet is needed for dependencies).
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the debug APK on your own Android device.

## Dependency
The project pins GeckoView `128.0.20240806093756` as a sample dependency. If unavailable from Mozilla Maven, select a currently published stable version and check API compatibility.

## Before public release
Implement and test engine storage clearing, supported UA overrides, anti-fingerprinting preferences, secure DNS and actual VPN tunnel integration, site permissions, accessibility, privacy policy, and automated tests. Do not market unverified protections as active.


## Device / User-Agent profile picker

The dashboard includes presets for selected Samsung Galaxy, Google Pixel, Xiaomi Redmi, OnePlus, and iPhone browser User-Agent strings. Choosing a preset creates a new GeckoSession and applies that User-Agent override; the selection is saved locally and can be changed with one tap.

**Important limitation:** this only changes the browser's User-Agent string. It does not turn the Android phone into the selected physical model, and does not change the OS, hardware, screen size, touch capabilities, GPS, IP address, TLS/network stack, or every JavaScript fingerprint. Websites may detect mismatches. The iPhone presets are Safari-like User-Agent strings running inside GeckoView, not real iOS Safari.


## Maximum practical browser profile spoofing (no root)

The dashboard includes a profile picker for Samsung Galaxy, Google Pixel, Xiaomi Redmi, OnePlus, and iPhone-style User-Agent presets. Selecting a profile creates a new GeckoSession, applies the preset User-Agent override, and reloads the current URL. The selection is saved locally.

This is intentionally described as **User-Agent spoofing**, not complete device emulation. A normal Android app cannot make the operating system or physical hardware become another phone. Sites may still infer device details from JavaScript APIs, screen dimensions, fonts, graphics behavior, TLS/network characteristics, Android permissions, and other signals. iPhone presets are Safari-like strings running inside GeckoView, not actual iOS Safari.

The project retains GeckoView strict tracking protection. It does not yet implement a real VPN tunnel, full browser-storage clearing, or verified comprehensive fingerprint resistance. Build and test in Android Studio before relying on it.
