package com.asif.privacyshield

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.os.Build
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.*
import android.text.InputType
import android.content.Context
import android.provider.Settings
import org.mozilla.geckoview.*
import java.net.URI
import java.util.UUID

class MainActivity : Activity() {
    private lateinit var runtime: GeckoRuntime
    private lateinit var session: GeckoSession
    private lateinit var browser: GeckoView
    private lateinit var address: EditText
    private lateinit var status: TextView
    private lateinit var root: LinearLayout
    private lateinit var dashboard: LinearLayout
    private lateinit var browserArea: LinearLayout
    private var customUA = ""
    private var activeProfile = "Default Android"
    private var dashboardVisible = true
    private val prefs by lazy { getSharedPreferences("privacy_shield", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(13,36,59)
        window.navigationBarColor = Color.rgb(13,36,59)

        val runtimeSettings = GeckoRuntimeSettings.Builder()
            .aboutConfigEnabled(false)
            .consoleOutput(false)
            .build()
        runtime = GeckoRuntime.create(this, runtimeSettings)
        customUA = prefs.getString("device_ua", "") ?: ""
        activeProfile = prefs.getString("device_profile", "Default Android") ?: "Default Android"
        session = createPrivacySession(customUA)
        session.open(runtime)
        buildUi()
        browser.setSession(session)
        session.loadUri("https://example.com")
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(246,248,251))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 14, 16, 12)
            setBackgroundColor(Color.rgb(13,36,59))
        }
        header.addView(TextView(this).apply {
            text = "🛡 Privacy Shield"
            textSize = 23f
            setTextColor(Color.WHITE)
            setTypeface(null, android.graphics.Typeface.BOLD)
        })
        header.addView(TextView(this).apply {
            text = "Privacy dashboard • status is not a guarantee of anonymity"
            textSize = 12f
            setTextColor(Color.rgb(211,224,235))
        })
        root.addView(header)

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(6, 3, 6, 3)
            setBackgroundColor(Color.WHITE)
        }
        nav.addView(makeButton("Dashboard") { showDashboard() })
        nav.addView(makeButton("Browser") { showBrowser() })
        nav.addView(makeButton("Leak Test") { session.loadUri("https://browserleaks.com/"); showBrowser() })
        root.addView(nav)

        dashboard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 10, 12, 20)
        }
        val scroll = ScrollView(this).apply { addView(dashboard) }
        root.addView(scroll, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        browserArea = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(8, 8, 8, 6)
            setBackgroundColor(Color.rgb(13,36,59))
        }
        address = EditText(this).apply {
            hint = "Search or enter address"
            singleLine = true
            imeOptions = EditorInfo.IME_ACTION_GO
            inputType = InputType.TYPE_TEXT_VARIATION_URI
            setTextColor(Color.WHITE)
            setHintTextColor(Color.LTGRAY)
            setPadding(12, 4, 12, 4)
            setBackgroundColor(Color.rgb(35,59,82))
            setOnEditorActionListener { _, action, _ ->
                if (action == EditorInfo.IME_ACTION_GO || action == EditorInfo.IME_ACTION_DONE) {
                    navigate(text.toString()); true
                } else false
            }
        }
        bar.addView(address, LinearLayout.LayoutParams(0, 48, 1f))
        bar.addView(makeButton("Go") { navigate(address.text.toString()) })
        browserArea.addView(bar)
        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(4, 2, 4, 2)
            setBackgroundColor(Color.WHITE)
        }
        controls.addView(makeButton("←") { if (session.canGoBack()) session.goBack() })
        controls.addView(makeButton("→") { session.goForward() })
        controls.addView(makeButton("Reload") { session.reload() })
        controls.addView(makeButton("Dashboard") { showDashboard() })
        browserArea.addView(controls)
        status = TextView(this).apply {
            text = "GeckoView • Strict tracking protection configured"
            textSize = 12f
            setTextColor(Color.rgb(32,78,83))
            setPadding(12, 7, 12, 7)
            setBackgroundColor(Color.rgb(224,243,239))
        }
        browserArea.addView(status)
        browser = GeckoView(this)
        browserArea.addView(browser, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))
        root.addView(browserArea, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))
        browserArea.visibility = View.GONE
        setContentView(root)

        attachProgressDelegate(session)
        populateDashboard()
    }

    private data class DeviceProfile(val label: String, val ua: String)

    private fun profiles(): List<DeviceProfile> = listOf(
        DeviceProfile("Default Android", ""),
        DeviceProfile("Samsung Galaxy S24", "Mozilla/5.0 (Linux; Android 14; SM-S921B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36"),
        DeviceProfile("Samsung Galaxy A54", "Mozilla/5.0 (Linux; Android 14; SM-A546B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36"),
        DeviceProfile("Google Pixel 8", "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36"),
        DeviceProfile("Google Pixel 7", "Mozilla/5.0 (Linux; Android 14; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36"),
        DeviceProfile("Xiaomi Redmi Note 13", "Mozilla/5.0 (Linux; Android 14; 2312DRA50G) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36"),
        DeviceProfile("OnePlus 12", "Mozilla/5.0 (Linux; Android 14; CPH2581) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36"),
        DeviceProfile("iPhone 15 Safari-like", "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1"),
        DeviceProfile("iPhone 14 Safari-like", "Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Mobile/15E148 Safari/604.1")
    )

    private fun showProfilePicker() {
        val list = profiles()
        val selected = list.indexOfFirst { it.label == activeProfile }.coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle("Choose browser profile")
            .setSingleChoiceItems(list.map { it.label }.toTypedArray(), selected) { dialog, which ->
                val chosen = list[which]
                dialog.dismiss()
                applyProfile(chosen.label, chosen.ua)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun applyProfile(label: String, ua: String) {
        activeProfile = label
        customUA = ua
        prefs.edit().putString("device_profile", label).putString("device_ua", ua).apply()
        val currentUrl = session.currentUri ?: "https://example.com"
        try { session.close() } catch (_: Exception) {}
        session = createPrivacySession(ua)
        attachProgressDelegate(session)
        session.open(runtime)
        browser.setSession(session)
        session.loadUri(currentUrl)
        populateDashboard()
        Toast.makeText(this, "Profile applied: $label", Toast.LENGTH_SHORT).show()
    }

    private fun createPrivacySession(ua: String): GeckoSession {
        val builder = GeckoSessionSettings.Builder()
            .trackingProtectionLevel(GeckoSessionSettings.TRACKING_PROTECTION_LEVEL_STRICT)
            .userAgentMode(GeckoSessionSettings.USER_AGENT_MODE_MOBILE)
        if (ua.isNotBlank()) builder.userAgentOverride(ua)
        return GeckoSession(builder.build())
    }

    private fun attachProgressDelegate(target: GeckoSession) {
        target.progressDelegate = object : GeckoSession.ProgressDelegate {
            override fun onPageStart(session: GeckoSession, url: String) {
                runOnUiThread { status.text = "Loading • ${safeHost(url)}" }
            }
            override fun onPageStop(session: GeckoSession, success: Boolean) {
                runOnUiThread {
                    status.text = if (success) "Loaded • ${safeHost(session.currentUri ?: "")}"
                    else "Load failed • Check connection"
                    address.setText(session.currentUri ?: "")
                }
            }
            override fun onProgressChange(session: GeckoSession, progress: Int) {}
        }
    }

    private fun populateDashboard() {
        dashboard.removeAllViews()
        val profileCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 13, 14, 13)
            setBackgroundColor(Color.WHITE)
        }
        profileCard.addView(TextView(this).apply {
            text = "📱 Device Profile Manager"
            textSize = 18f
            setTextColor(Color.rgb(13,36,59))
            setTypeface(null, android.graphics.Typeface.BOLD)
        })
        profileCard.addView(TextView(this).apply {
            text = "Selected: $activeProfile\\nChanges the browser User-Agent only; this cannot change your real phone or hide every fingerprint signal."
            textSize = 12f
            setTextColor(Color.rgb(92,105,119))
            setPadding(0, 5, 0, 8)
        })
        profileCard.addView(makeButton("Choose fake mobile profile") { showProfilePicker() })
        profileCard.addView(makeButton("Reset to default profile") { applyProfile("Default Android", "") })
        dashboard.addView(profileCard, LinearLayout.LayoutParams(-1, -2).apply {
            bottomMargin = dp(10)
        })

        val protect = Button(this).apply {
            text = "⚡ ONE-CLICK PROTECT"
            textSize = 17f
            isAllCaps = false
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(21,105,89))
            setOnClickListener { oneClickProtect() }
        }
        dashboard.addView(protect, LinearLayout.LayoutParams(-1, 58).apply {
            bottomMargin = dp(10)
        })
        val vpnCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 13, 14, 13)
            setBackgroundColor(Color.WHITE)
        }
        vpnCard.addView(TextView(this).apply {
            text = "🔒 Built-in VPN"
            textSize = 18f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(Color.rgb(13,36,59))
        })
        vpnCard.addView(TextView(this).apply {
            text = "Status: Not connected • No VPN server configured"
            textSize = 14f
            setTextColor(Color.rgb(170,75,30))
            setPadding(0, 5, 0, 4)
        })
        vpnCard.addView(TextView(this).apply {
            text = "A VPN needs a real provider/server and configuration. This source project does not include a VPN server or tunnel implementation, so it will not falsely claim to hide your IP."
            textSize = 12f
            setTextColor(Color.rgb(92,105,119))
        })
        vpnCard.addView(makeButton("Set up VPN") { showVpnSetup() },
            LinearLayout.LayoutParams(-1, 48).apply { topMargin = dp(8) })
        dashboard.addView(vpnCard, LinearLayout.LayoutParams(-1, -2).apply {
            bottomMargin = dp(10)
        })
        dashboard.addView(TextView(this).apply {
            text = "Browser & network"
            textSize = 18f
            setTextColor(Color.rgb(13,36,59))
            setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(2, 8, 2, 5)
        })
        addStatusCard("Public IP Address", "Not measured yet", "Run a network leak test to observe public IPv4/IPv6.")
        addStatusCard("DNS / WebRTC", "Test required", "No VPN or custom DNS tunnel is configured by this starter.")
        addStatusCard("User-Agent / profile", activeProfile,
            if (customUA.isBlank()) "GeckoView default mobile User-Agent is in use."
            else "Preset User-Agent override is active. Other signals may still reveal the actual device.")
        dashboard.addView(TextView(this).apply {
            text = "Fingerprint & device"
            textSize = 18f
            setTextColor(Color.rgb(13,36,59))
            setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(2, 12, 2, 5)
        })
        addStatusCard("Canvas / WebGL / AudioContext", "Protection not verified", "Strict tracking protection does not guarantee full anti-fingerprinting.")
        addStatusCard("Screen details", "${resources.displayMetrics.widthPixels} × ${resources.displayMetrics.heightPixels} px", "Android display metrics; sites may receive different CSS-pixel values.")
        addStatusCard("Device hardware", "Android ${Build.VERSION.RELEASE} • API ${Build.VERSION.SDK_INT}", "CPU cores: ${Runtime.getRuntime().availableProcessors()} • model: ${Build.MANUFACTURER} ${Build.MODEL}")
        addStatusCard("Sensors & permissions", "Per-site controls incomplete", "This starter does not automatically grant sensor permissions.")
        dashboard.addView(TextView(this).apply {
            text = "Storage & identifiers"
            textSize = 18f
            setTextColor(Color.rgb(13,36,59))
            setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(2, 12, 2, 5)
        })
        addStatusCard("Cookies / Local Storage", "GeckoView storage not inspected", "Clear-all storage is not wired to the engine storage API yet.")
        val appUuid = prefs.getString("app_uuid", null) ?: UUID.randomUUID().toString().also {
            prefs.edit().putString("app_uuid", it).apply()
        }
        addStatusCard("App-scoped UUID", appUuid, "This identifier belongs only to this browser app; regenerate below.")
        addStatusCard("Advertising ID", "Not read", "Android system setting controls the Advertising ID; this app cannot arbitrarily set it.")
        dashboard.addView(makeButton("Regenerate app UUID") {
            val next = UUID.randomUUID().toString()
            prefs.edit().putString("app_uuid", next).apply()
            Toast.makeText(this, "App UUID regenerated", Toast.LENGTH_SHORT).show()
            populateDashboard()
        }, LinearLayout.LayoutParams(-1, 48).apply { topMargin = dp(8) })
        dashboard.addView(makeButton("Clear app cache + rotate app UUID") {
            clearAppCacheAndRotateUuid()
        }, LinearLayout.LayoutParams(-1, 48).apply { topMargin = dp(8) })
        dashboard.addView(makeButton("Privacy settings") { showPrivacySettings() },
            LinearLayout.LayoutParams(-1, 48).apply { topMargin = dp(8) })
        dashboard.addView(makeButton("Open browser") { showBrowser() },
            LinearLayout.LayoutParams(-1, 48).apply { topMargin = dp(8) })
    }

    private fun addStatusCard(title: String, value: String, note: String) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(13, 11, 13, 11)
            setBackgroundColor(Color.WHITE)
        }
        card.addView(TextView(this).apply {
            text = title
            textSize = 14f
            setTextColor(Color.rgb(77,91,106))
        })
        card.addView(TextView(this).apply {
            text = value
            textSize = 16f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(Color.rgb(25,45,64))
            setPadding(0, 3, 0, 3)
        })
        card.addView(TextView(this).apply {
            text = note
            textSize = 12f
            setTextColor(Color.rgb(92,105,119))
        })
        dashboard.addView(card, LinearLayout.LayoutParams(-1, -2).apply {
            bottomMargin = dp(8)
        })
    }

    private fun oneClickProtect() {
        // Do only operations this starter can actually perform. GeckoView cookies/site
        // storage and network identity are deliberately not claimed to be cleared.
        clearAppCacheAndRotateUuid(showToast = false)
        AlertDialog.Builder(this)
            .setTitle("One-Click Protect")
            .setMessage(
                "Completed: rotated this app's UUID and requested deletion of this app's cache.\n\n" +
                "Already configured: GeckoView strict tracking protection for this session.\n\n" +
                "Still needs external setup: a real VPN server/provider and profile. This button does NOT clear GeckoView cookies/site storage, change your public IP, reset Android Advertising ID, or guarantee protection against all fingerprinting."
            )
            .setPositiveButton("Set up VPN") { _, _ -> showVpnSetup() }
            .setNeutralButton("Privacy settings") { _, _ -> showPrivacySettings() }
            .setNegativeButton("OK", null)
            .show()
    }

    private fun clearAppCacheAndRotateUuid(showToast: Boolean = true) {
        var cacheCleared = true
        try {
            cacheCleared = cacheDir.deleteRecursively() && (externalCacheDir?.deleteRecursively() != false)
        } catch (_: Exception) {
            cacheCleared = false
        }
        val next = UUID.randomUUID().toString()
        prefs.edit().putString("app_uuid", next).apply()
        populateDashboard()
        if (showToast) {
            val msg = if (cacheCleared) "App cache cleared; app UUID rotated" else "UUID rotated; cache clearing was incomplete"
            Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
        }
    }

    private fun showPrivacySettings() {
        val options = arrayOf(
            "Open Android VPN settings",
            "Open browser leak-test page",
            "Clear app cache + rotate app UUID",
            "About privacy limitations"
        )
        AlertDialog.Builder(this)
            .setTitle("Privacy settings")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> showVpnSetup()
                    1 -> { session.loadUri("https://browserleaks.com/"); showBrowser() }
                    2 -> clearAppCacheAndRotateUuid()
                    3 -> AlertDialog.Builder(this)
                        .setTitle("Privacy limitations")
                        .setMessage("Strict tracking protection is enabled for this GeckoView session. No in-app VPN tunnel is included. Cookies/site storage clearing, custom DNS, verified WebRTC blocking, full anti-fingerprinting, and system Advertising ID reset are not implemented. Do not assume this app makes you anonymous.")
                        .setPositiveButton("OK", null).show()
                }
            }.show()
    }

    private fun showVpnSetup() {
        AlertDialog.Builder(this)
            .setTitle("Set up built-in VPN")
            .setMessage(
                "A built-in VPN needs a real VPN provider or your own VPN server. " +
                "This project currently has no tunnel backend or server profile. " +
                "For now, connect a trusted VPN through Android Settings.\n\n" +
                "To make VPN work inside this app, the next step is to add a supported tunnel backend " +
                "(for example WireGuard) and import a valid provider/server configuration. " +
                "Never use a random free VPN profile from an unknown source."
            )
            .setPositiveButton("Open Android VPN settings") { _, _ ->
                try {
                    startActivity(android.content.Intent(android.provider.Settings.ACTION_VPN_SETTINGS))
                } catch (_: Exception) {
                    Toast.makeText(this, "Open Android Settings > Network & Internet > VPN", Toast.LENGTH_LONG).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showDashboard() {
        dashboardVisible = true
        dashboard.parent?.let { (it as? View)?.visibility = View.VISIBLE }
        // dashboard is inside a ScrollView; hide browser container.
        browserArea.visibility = View.GONE
        (dashboard.parent as? View)?.visibility = View.VISIBLE
    }

    private fun showBrowser() {
        dashboardVisible = false
        (dashboard.parent as? View)?.visibility = View.GONE
        browserArea.visibility = View.VISIBLE
    }

    private fun makeButton(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            textSize = 12f
            isAllCaps = false
            setPadding(5, 0, 5, 0)
            setOnClickListener { action() }
        }

    private fun navigate(raw: String) {
        val value = raw.trim()
        if (value.isEmpty()) return
        val url = when {
            value.startsWith("https://", true) || value.startsWith("http://", true) -> value
            value.contains(".") && !value.contains(" ") -> "https://$value"
            else -> "https://www.google.com/search?q=" + java.net.URLEncoder.encode(value, "UTF-8")
        }
        try {
            val scheme = URI(url).scheme?.lowercase()
            if (scheme != "https" && scheme != "http") {
                Toast.makeText(this, "Only HTTP/HTTPS addresses are supported", Toast.LENGTH_SHORT).show()
                return
            }
            session.loadUri(url)
        } catch (_: Exception) {
            Toast.makeText(this, "Invalid address", Toast.LENGTH_SHORT).show()
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun safeHost(url: String): String = try { URI(url).host ?: url } catch (_: Exception) { url }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (::session.isInitialized && session.canGoBack()) session.goBack()
        else if (dashboardVisible) super.onBackPressed()
        else showDashboard()
    }

    override fun onDestroy() {
        if (::session.isInitialized) session.close()
        super.onDestroy()
    }
}
