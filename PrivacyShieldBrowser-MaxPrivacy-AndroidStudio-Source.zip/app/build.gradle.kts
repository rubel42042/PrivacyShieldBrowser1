plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.asif.privacyshield"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.asif.privacyshield"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
    }
}
dependencies {
    implementation("org.mozilla.geckoview:geckoview:128.0.20240806093756")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
}
